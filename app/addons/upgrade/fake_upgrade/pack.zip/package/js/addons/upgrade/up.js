function fn_upgrade_say_hello()
{
	alert('hello');
}