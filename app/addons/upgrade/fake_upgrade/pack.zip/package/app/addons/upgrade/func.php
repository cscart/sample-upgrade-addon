<?php

function fn_upgrade_say_hello($who = 'world')
{
    echo '<h1>Hello' . $who . '</h1>';
}
